@extends ('index')

@section('content')

<h3>Ваш заказ № {{$order_id}} успешно оформлен</h3>

@stop
   