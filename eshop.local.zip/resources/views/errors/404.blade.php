@extends ('index')

@section ('content')

<h2>Ошибка 404</h2>
<h3>На нашем сайте нет такой страницы</h3>

@stop